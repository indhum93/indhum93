import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  session!: any;
  constructor(private route:Router) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      this.session = localStorage.getItem('loginStatus');
      if(JSON.parse(this.session)==1)
        {
          return true;
        }
        else if(JSON.parse(this.session)==2){
          return true;
        }
        else{
          this.route.navigate(['']);
          return false;
        }
  }
}
