import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class QuizServiceService {
  constructor(private http: HttpClient) { 
  }
  public headerObj = new HttpHeaders().set('Content-Type', 'application/json');
  getAllCategory(){
    const httpOptions = { headers: this.headerObj };
    return this.http.get('https://opentdb.com/api_category.php', httpOptions); 
  }
  getCategoryByID(id:any){   
    const httpOptions = { headers: this.headerObj };
    return this.http.get('https://opentdb.com/api.php?amount=10&category='+id,httpOptions);
  }
}
