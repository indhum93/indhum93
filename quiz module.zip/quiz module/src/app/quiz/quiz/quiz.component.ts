import { Component, OnInit } from '@angular/core';
import { QuizServiceService } from 'src/app/quiz-service.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  currentURl:any;
  quiz:any;
  questions: any;
  currentQuiz:number=0;
  scores: number=0;
  btnSubmit: string="Next";
  isDisabled = false;
  result: any;
  inCorrectAnswer: any;
  correctAnswer!: any;
  next=true;
  options!:any[];
  quizForm: any;
  submitted: boolean= false;
  
  constructor(private formBuilder: FormBuilder,private qservice:QuizServiceService,private route:Router, private activeRoute:ActivatedRoute) {
    
   }
  
  ngOnInit(): void {  
    // category id
    this.activeRoute.params.subscribe(params => {
      this.currentURl=params['page'];
    }); 
    //quiz data
    this.qservice.getCategoryByID(this.currentURl).subscribe(res=>{
      this.quiz=res;
      this.questions=this.quiz.results;
      this.optionSelection();
    })
    // Form submit
    this.quizForm=this.formBuilder.group({
      answer:['', Validators.required]
    })
  }
  optionSelection(){
    // random options 
    this.questions[this.currentQuiz].incorrect_answers.push(this.questions[this.currentQuiz].correct_answer)
    this.questions[this.currentQuiz].incorrect_answers.sort(()=> {
      return Math.random()-0.5;
    });
    
  }
  confirm(){ 
    // Form submit 
    this.submitted = true;
    if(this.quizForm.invalid){
      return;
    }
    else{
      this.checkAnswer(this.quizForm.value.answer);
    }
  }
  nextQuiz(){
    // next quiz
    this.submitted=true;
    this.currentQuiz=this.currentQuiz+1;    
    if(this.currentQuiz == 10){ 
      this.btnSubmit="Submit"; 
      localStorage.setItem('loginStatus','2');
      localStorage.setItem('scores',JSON.stringify(this.scores));
      this.route.navigate(['result']);    
    }
    else{
      this.inCorrectAnswer='';
      this.correctAnswer='';   
      this.isDisabled=false;
      this.next=true;
      this.optionSelection();
    }    
  }
  get f() { return this.quizForm.controls; }
  checkAnswer($value:any){    
    // display result
    this.next=false;
    this.isDisabled=true;
    this.result=this.questions[this.currentQuiz].correct_answer;    
    if($value==this.result){
      this.scores=this.scores+1;
    }
    this.correctAnswer=`Correct Answer : ${this.result}`;    
     
  }
}
