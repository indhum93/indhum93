import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { QuizServiceService } from 'src/app/quiz-service.service';
@Component({
  selector: 'app-category-selection',
  templateUrl: './category-selection.component.html',
  styleUrls: ['./category-selection.component.css']
})
export class CategorySelectionComponent implements OnInit {
  quizForm!: FormGroup;
  quizCategories: any;
  category:any;
  qcategory: any;
  submitted: boolean= false;
  constructor(private formBuilder: FormBuilder,private router:Router,private qservice:QuizServiceService){
   
  }
  ngOnInit():void{
    // Form Submit
    this.quizForm=this.formBuilder.group({
      name:['', Validators.required],
      category:['', Validators.required]
    })
    this.qservice.getAllCategory().subscribe(res=>{
      this.quizCategories=res;
      this.qcategory=this.quizCategories.trivia_categories;     
    })
  }
  get f() { return this.quizForm.controls; }
  takeQuiz():void{
    // category selection
    this.submitted = true;
    if(this.quizForm.invalid){
      return;
    }
    else{
      localStorage.setItem('loginStatus','1');
      this.router.navigate(['/quiz',this.quizForm.value.category]);
    }
  }
  onReset() {
    // reset
    this.submitted = false;
    this.quizForm.reset();
  }
}
