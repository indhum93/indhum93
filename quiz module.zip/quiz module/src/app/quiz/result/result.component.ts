import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  result: any;
  score:any;
  constructor(private route:Router) { }

  ngOnInit(): void {
    this.result=localStorage.getItem('scores');
    JSON.parse(this.result);
    if(this.result <= 5){
      this.score='text-danger';
    }
    else{
      this.score='text-success';
    }
  }
  home(){
    localStorage.clear();
    this.route.navigate(['']);
  }
  onDestroy(){
    localStorage.clear();
  }
}
